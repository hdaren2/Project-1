
/**
* <Represents a Car object with make, year, and price attributes.>
*
* CSC 1351 Programming Project No <1>
* Section <002>
*
* @author <Hunter D'Arensbourg>
* @since <3/17/21>
*
*/
public class Car implements Comparable <Car> {
	private String make;
	private int year;
	private int price; 

	/**
	* <Constructor for Car that sets the values of make, year, and price.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public Car(String make, int year, int price) {
		this.make = make;
		this.year = year;
		this.price = price;
	}
	
	/**
	* <Get method to return the value of make.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public String getMake() {
		return make;
	}
	
	/**
	* <Get method to return the value of year.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public int getYear() {
		return year;
	}
	
	/**
	* <Get method to return the value of price.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public int getPrice() {
		return price;
	}
	
	/**
	* <Compares Car objects based on make, then year.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public int compareTo(Car other) {
		if (!this.make.equals(other.make)) {
			return this.make.compareTo(other.make);
	    } else {
	        return Integer.compare(this.year, other.year);
	    }
	}
	
	/**
	* <Returns a String displaying the make, year, and price of the Car object.>
	 *
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public String toString() {
		return "Make: " + make + ", Year: " + year + ", Price: " + price + ";";
	}
}
	

