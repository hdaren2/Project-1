import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
* <Main class that contains the functionality of the program, including reading data from input files, creating aOrderedList objects, and writing data for output files.>
*
* CSC 1351 Programming Project No <1>
* Section <002>
*
* @author <Hunter D'Arensbourg>
* @since <3/17/21>
*
*/
public class Prog01_aOrderedList {
	
	/**
	* <Main method of the program. Prompts user for filename of input file, reads data from input file, prompts user for filename of output file, writes the data to the output file after performing necessary functions, and handles exceptions.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public static void main(String[] args) throws FileNotFoundException {
		
		aOrderedList orderedList = new aOrderedList();
        Scanner scanner = GetInputFile("Enter input filename: ");
        
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] parts = line.split(",");
                if (parts[0].equals("A")) {
                    if (parts.length == 4) {
                        orderedList.add(new Car(parts[1], Integer.parseInt(parts[2]), Integer.parseInt(parts[3])));
                    }
                } else if (parts[0].equals("D")) {
                	String make = parts[1];
                	int year = Integer.parseInt(parts[2]);
                	deleteCar(orderedList, make, year);	 	
                }
        }
        scanner.close();
        
        PrintWriter writer = GetOutputFile("Enter output filename: ");
        
        writer.println("Number of cars: " + orderedList.size());
        for (int i = 0; i < orderedList.size(); i++) {
        	Comparable car = orderedList.get(i);
        	String formattedPrice = "$" + String.format("%,d" , ((Car) car).getPrice());
            writer.printf("\nMake:  %10s", ((Car) car).getMake());
            writer.printf("\nYear:  %10d", ((Car) car).getYear());
            writer.printf("\nPrice: %10s\n", formattedPrice);
        }
        writer.close();
    }
	        		
	/**
	* <Get method to obtain the filename of the input file and returns a Scanner object.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
	
		Scanner scanner = new Scanner(System.in);
	    while (true) {
	    	System.out.print(UserPrompt);
	        String fileName = scanner.nextLine();
	        try {
	        	return new Scanner(new File(fileName));
	        } catch (FileNotFoundException e) {
	        	System.out.println("File specified <" + fileName + "> does not exist. Would you like to continue? <Y/N> ");
	            String choice = scanner.nextLine();
	            if (choice.equalsIgnoreCase("N")) {
	            	System.out.println("Program terminated.");
	            	System.exit(0);
	            }
	        }
	    }
	}
	
	/**
	* <Get method used to obtain the filename of the output file and returns new PrintWriter object.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public static PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException {
	       
		Scanner scanner = new Scanner(System.in);
	    while (true) {
	    	System.out.print(UserPrompt);
	        String fileName = scanner.nextLine();
	        try {
	        	return new PrintWriter(fileName);
	        } catch (FileNotFoundException e) {
	        	System.out.println("Error: File specified <" + fileName + "> is not valid or write-protected. Would you like to continue? <Y/N>");
	            String choice = scanner.nextLine();
	            if (choice.equalsIgnoreCase("N")) {
	                System.exit(0);
	            }
	        }
	        scanner.close();
	    }
	}
	
	/**
	* <Method used to delete a Car object from the ordered list.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public static void deleteCar(aOrderedList orderedList, String make, int year) {
		for (int i = 0; i < orderedList.size(); i++) {
			Car car = (Car) orderedList.get(i);
	        if (car.getMake().equals(make) && car.getYear() == year) {
	        	orderedList.remove(i);
	            break; 
	        }
	    }
	}
}
    
    


	
	

	
