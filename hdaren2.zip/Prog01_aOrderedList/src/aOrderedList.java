import java.util.Arrays;
/**
* <This class represents an ordered list of Car objects. It keeps the Car objects sorted after each addition or subtraction from the array.>
*
* CSC 1351 Programming Project No <1>
* Section <002>
*
* @author <Hunter D'Arensbourg>
* @since <3/17/21>
*
*/
public class aOrderedList {
	final int SIZEINCREMENTS = 20;
	private Comparable[] oList;
	private int listSize;
	private int numObjects;
	private int curr;
	
	/**
	* <This method is a constructor for the aOrderedList object.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public aOrderedList() {
		numObjects = 0;
		listSize = SIZEINCREMENTS;
		this.oList = new Car[listSize];
	}
	
	/**
	* <This method adds a new car to the ordered list in the correct position to maintain sorted order.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	void add(Comparable newObject) {
		if (numObjects == listSize) {
            resizeArray();
        }
		int index = 0;
       
	    while (index < numObjects && oList[index].compareTo(newObject) < 0) {
            index++;
        }

        for (int i = numObjects; i > index; i--) {
            oList[i] = oList[i - 1];
        }

        oList[index] = newObject;
        numObjects++;
    }
	
	/**
	* <Returns the toString values of the list objects, separated by commas, and delimited by brackets. This method calls the toString of the Car objects in the oList array to construct the value of the return method.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public String toString() {
		 StringBuilder result = new StringBuilder();
		 result.append("[");
	     
		 for (int i = 0; i < numObjects; i++) {
			 result.append(oList[i].toString());
	         
			 if (i < numObjects - 1) {
	            	result.append(", ");
	            }
	     }
	     result.append("]");
	     return result.toString();
	}
	
	/**
	* <Resizes the array if necessary when Car object are added or deleted.>
	*
    * CSC 1351 Programming Project No <1>
    * Section <002>
    *
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	private void resizeArray() {
	     listSize += SIZEINCREMENTS;
	     oList = Arrays.copyOf(oList, 2 * listSize);
	}
	
	/**
	* <Returns the number of elements in this list.>
	*
  	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public int size() {
	     return numObjects;
	}
		
	/**
	* <Returns the element at the specified position in this list.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public Comparable get(int index) {
		if (index < 0 || index >= numObjects) {
			throw new IndexOutOfBoundsException("Index out of bounds");
	    }
			return (Car) oList[index];
	    }
		
	/**
	* <Returns true if array is empty and false otherwise.>
	*
	* CSC 1351 Programming Project No <1>
    * Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public boolean isEmpty() {
		if (numObjects == 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	* <Removes the element at the specified position in the list.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public void remove(int index) {
	    for (int i = index; i < numObjects - 1; i++) {
	    	oList[i] = oList[i + 1];
	    }
	    oList[numObjects - 1] = null;
	    numObjects--;
	}
			 
	/**
	* <Resets iterator parameters so that the "next" element is the first element in the array, if any.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public void reset() {
		curr = 0;
	}
		 
	/**
	* <Returns the next element in the iteration and increments the iterator parameters.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public Comparable next() {
		if (curr < numObjects) {
			return (Comparable<?>) oList[curr++];
		} else {
			return null;
		}
	}
		 
	/**
	* <Returns true if the iteration has more elements to iterate through.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public boolean hasNext() {
		if (curr < numObjects) {
			return true;
		} else {
			return false;
		}
	}
		
	/**
	* <Removes the last element returned by the next() method.>
	*
	* CSC 1351 Programming Project No <1>
	* Section <002>
	*
	* @author <Hunter D'Arensbourg>
	* @since <3/17/21>
	*
	*/
	public void remove() {
		if (curr > 0) {
		    curr--;
		}
	}
}


